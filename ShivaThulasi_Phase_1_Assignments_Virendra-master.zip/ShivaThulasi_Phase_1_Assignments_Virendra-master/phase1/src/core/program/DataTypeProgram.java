package core.program;

public class DataTypeProgram {

	public static void main(String[] args) {
		boolean status = true;
     System.out.println("i am printing status "  + status);
      char gender='F';
System.out.println("i am printing gender " + gender);
int age=23;
System.out.println("i am printing age " + age);
	}

}
