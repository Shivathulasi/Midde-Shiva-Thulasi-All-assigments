package assignment_Phase1;

public class TwoDimensionalArray {
	public static void main(String[] args) {
    int[][] a = {{2, 4, 6, 8}, {3, 6, 9} };
		      System.out.println("\nLength of row 1: " + a[0].length);
		      }
		}

	
